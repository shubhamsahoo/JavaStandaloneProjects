package com.nit.test;

public class JobRegistrationAppTest {

	public static void main(String[] args) {
		//call register method
		com.nit.jdbc.JobRegistraionApp.register();
	}
}
